﻿using System;
using log4net;
using log4net.Repository;
using log4net.Appender;
using System.Reflection;

namespace SiteListCtrl.Util
{
    /// <summary>
    /// ログを出力するクラスです。
    /// 
    /// </summary>
    public class Logger
    {
        private static readonly ILog logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        //private static readonly ILog logger = LogManager.GetLogger("SiteList");

        private Logger() { }

        /// <summary>
        /// メッセージをデバッグログとして出力します。
        /// </summary>
        /// <param name="message">メッセージ</param>
        public static void Debug(string message)
        {
            logger.Debug(message);
        }

        /// <summary>
        /// メッセージをデバッグログとして出力します。
        /// </summary>
        /// <param name="message">メッセージ</param>
        public static void Debug(string message, Exception ex)
        {
            logger.Debug(message);
        }

        /// <summary>
        /// メッセージをインフォメーションログとして出力します。
        /// </summary>
        /// <param name="message">メッセージ</param>
        public static void Info(string message)
        {
            logger.Info(message);
        }

        public static void Info(string message, Exception ex)
        {
            logger.Info(message, ex);
        }

        /// <summary>
        /// メッセージを警告ログとして出力します。
        /// </summary>
        /// <param name="message">メッセージ</param>
        public static void Warn(string message)
        {
            logger.Warn(message);
        }

        public static void Warn(string message, Exception ex)
        {
            logger.Warn(message, ex);
        }

        /// <summary>
        /// メッセージをエラーログとして出力します。
        /// </summary>
        /// <param name="message">メッセージ</param>
        public static void Error(string message)
        {
            logger.Error(message);
        }

        public static void Error(string message, Exception ex)
        {
            logger.Error(message, ex);
        }

        public static void Fatal(string message)
        {
            logger.Fatal(message);
        }

        public static void Fatal(string message, Exception ex)
        {
            logger.Fatal(message, ex);
        }

        public static string GetLogFileName()
        {
            foreach (ILoggerRepository repository in LogManager.GetAllRepositories())
            {
                foreach (IAppender appender in repository.GetAppenders())
                {
                    RollingFileAppender fileAppender = appender as RollingFileAppender;
                    if (fileAppender == null)
                        continue;
                    //
                    if (!fileAppender.Name.Equals("RollingLogFileAppender"))
                        continue;
                    //
                    return fileAppender.File;
                }
            }
            return string.Empty;
        }

        public static int GetLogBackups()
        {
            foreach (ILoggerRepository repository in LogManager.GetAllRepositories())
            {
                foreach (IAppender appender in repository.GetAppenders())
                {
                    RollingFileAppender fileAppender = appender as RollingFileAppender;
                    if (fileAppender == null)
                        continue;
                    //
                    if (!fileAppender.Name.Equals("RollingLogFileAppender"))
                        continue;
                    //
                    return fileAppender.MaxSizeRollBackups;
                }
            }
            return 1;
        }
    }
}
