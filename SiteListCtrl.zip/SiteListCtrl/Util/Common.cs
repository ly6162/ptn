﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Xml.Linq;
using SiteListCtrl.Util;
using System.Windows.Forms;

namespace SiteListCtrl.Util
{
    class Common
    {

        public Common()
        {
        }

        /// <summary>
        /// レジストリ処理
        /// </summary>
        /// <param name="mode">起動モード 0:レジストリ登録 1:起動チェック</param>
        /// <returns>Task<int> result 0:成功 904:iniファイルエラー 999:エラー</returns>
        public async Task<int> RegistryCtrl(int mode = 0)
        {
            //Logger.Debug("RegistryCtrl() start");
            Common cm = new Common();
            CommonHttp ch = new CommonHttp();
            int result = CommonCode.ERROR;
            //iniファイルを取得
            Dictionary<string, string> iniDictionary = GetIni.GetIni.GetReadValue();
            if (iniDictionary == null)
            {
                return CommonCode.ERROR_READ_FILE;
            }

            try
            {
                //HKEY_LOCAL_MACHINEに登録されているか確認
                RegistryKey key = Registry.LocalMachine.OpenSubKey(iniDictionary["keyNameLM"]);
                int isMode = 0;
                string path = "";
                if (key != null)
                {
                    //登録されている場合名前と値のペアを取得できるか確認
                    if (key.GetValue(iniDictionary["isMode"]) != null)
                    {
                        isMode = (int)key.GetValue(iniDictionary["isMode"]);
                    }
                    if (key.GetValue(iniDictionary["sitelistPath"]) != null)
                    {
                        path = (string)key.GetValue(iniDictionary["sitelistPath"]);
                    }
                    key.Close();
                    if(isMode == 0 && path != "")
                    {
                        //IEモードが無効
                        Logger.Debug(CommonMessage.MSG_NO_IEMODE);
                        return CommonCode.CODE_FALSE_IEMODE;
                    }
                    if (isMode != 1 || path == "")
                    {
                        //新規登録
                        Logger.Debug(CommonMessage.MSG_NO_KEY);
                        bool createResult = cm.CreateValue(iniDictionary["keyNameLM"], iniDictionary["isMode"], iniDictionary["sitelistPath"], iniDictionary["downloadUri"]);
                        if (!createResult)
                        {
                            //登録エラー
                            Logger.Debug(CommonMessage.ERROR_REGISTRY_FAILURE);
                            return CommonCode.ERROR;
                        }
                        Logger.Debug(CommonMessage.MSG_REGIST);
                        return CommonCode.OK;
                    }

                    //レジストリに登録したサイトリストのパスが指定値かどうか確認
                    if (path != iniDictionary["downloadUri"])
                    {
                        Logger.Debug(CommonMessage.MSG_OTHER_FILE);
                        Logger.Info("[show message] msg2");
                        Console.WriteLine(iniDictionary["msg2"]);
                        //MessageBox.Show(iniDictionary["msg2"], CommonMessage.DIALOG_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                        //指定パス以外の場合書き込み権限があるか確認
                        //bool isWritable = cm.IsWritableFile(path);
                        //if(isWritable == false)
                        //{
                        //    Logger.Debug(CommonMessage.MSG_NO_AUTHORITY);
                        //    return CommonCode.CODE_NO_AUTHORITY;
                        //}
                        ////SLI向けのサイトリスト設定とすべて合致するか確認
                        //bool compareResult = cm.CompareList(path, iniDictionary["downloadUri"], iniDictionary["comment"]);
                        //if (!compareResult)
                        //{
                        //    //設定に1つ以上の差異ある場合中身をサーバー上のファイルで書き換える
                        //    var copyResult = await ch.DownloadFile(iniDictionary["downloadUri"], path);
                        //    if (copyResult == false)
                        //    {
                        //        Logger.Debug(CommonMessage.ERROR);
                        //        return CommonCode.ERROR_HTTP_REQUEST;
                        //    }
                        //}
                    }
                    result = CommonCode.OK;
                }
                else
                {
                    //HKEY_CURRENT_USERに登録されているか確認
                    RegistryKey cuKey = Registry.CurrentUser.OpenSubKey(iniDictionary["keyNameCU"]);
                    int cuMode = 0;
                    string cuPath = "";
                    if (cuKey != null)
                    {
                        
                        if (cuKey.GetValue(iniDictionary["isMode"]) != null)
                        {
                            cuMode = (int)cuKey.GetValue(iniDictionary["isMode"]);
                        }
                        if (cuKey.GetValue(iniDictionary["sitelistPath"]) != null)
                        {
                            cuPath = (string)cuKey.GetValue(iniDictionary["sitelistPath"]);
                        }
                        cuKey.Close();
                        if (cuMode == 0 && cuPath != "")
                        {
                            //IEモードが無効
                            Logger.Debug(CommonMessage.MSG_NO_IEMODE);
                            return CommonCode.CODE_FALSE_IEMODE_HKCU;
                        }
                        if (cuMode != 1 || cuPath == "")
                        {
                            //新規登録
                            Logger.Debug(CommonMessage.MSG_NO_KEY);
                            bool createResult = cm.CreateValue(iniDictionary["keyNameLM"], iniDictionary["isMode"], iniDictionary["sitelistPath"], iniDictionary["downloadUri"]);
                            if (!createResult)
                            {
                                //登録エラー
                                Logger.Debug(CommonMessage.ERROR_REGISTRY_FAILURE);
                                return CommonCode.ERROR;
                            }
                            Logger.Debug(CommonMessage.MSG_REGIST);
                            return CommonCode.OK;
                        }

                        //レジストリに登録したサイトリストのパスが指定値かどうか確認
                        if (cuPath != iniDictionary["downloadUri"])
                        {
                            Logger.Debug(CommonMessage.MSG_OTHER_FILE);
                            //指定パス以外の場合書き込み権限があるか確認
                            bool isWritable = cm.IsWritableFile(cuPath);
                            Logger.Info("IsWritableFile()" + isWritable);
                            if (isWritable == false)
                            {
                                Logger.Debug(CommonMessage.MSG_NO_AUTHORITY);
                                return CommonCode.CODE_NO_AUTHORITY;
                            }
                            //指定パス以外の場合、SLI向けのサイトリスト設定とすべて合致するか確認
                            bool compareResult = cm.CompareSiteList(path, iniDictionary["downloadUri"], iniDictionary["comment"]);
                            if (!compareResult)
                            {
                                //設定に1つ以上の差異ある場合
                                DateTime dt = DateTime.Now;
                                string today = dt.ToString("yyyyMMdd_HHmmss");
                                string orgDirName = Path.GetDirectoryName(cuPath);
                                string orgFileName = Path.GetFileNameWithoutExtension(cuPath);
                                //ファイルのバックアップを保存
                                File.Copy(cuPath, orgDirName + "\\" + orgFileName + today + ".xml");
                                //中身をサーバー上のファイルで書き換える
                                var copyResult = await ch.CopyFileAsync(iniDictionary["downloadUri"], cuPath);
                                if(copyResult == false)
                                {
                                    Logger.Debug(CommonMessage.ERROR);
                                    return CommonCode.ERROR_HTTP_REQUEST;
                                }
                                Logger.Debug(CommonMessage.MSG_DOWNLOAD_SUCCESS);
                            }
                        }
                        result = CommonCode.OK;
                    }
                    else
                    {
                        if(mode != 0)
                        { //iemodecheckでHKCUにも未登録の場合メッセージ表示のみ
                            Logger.Debug(CommonMessage.MSG_NO_KEY);
                            return CommonCode.CODE_NO_KEY;
                        }
                        //新規登録
                        Logger.Debug(CommonMessage.MSG_NO_KEY);
                        bool createResult = cm.CreateValue(iniDictionary["keyNameLM"], iniDictionary["isMode"], iniDictionary["sitelistPath"], iniDictionary["downloadUri"]);
                        if (!createResult)
                        {
                            //登録エラー
                            Logger.Debug(CommonMessage.ERROR);
                            return CommonCode.ERROR;
                        }
                        Logger.Debug(CommonMessage.MSG_REGIST);
                        result = CommonCode.OK;
                    }
                }
            }
            catch (HttpRequestException re)
            {
                //通信エラー
                Logger.Error(re.Message, re);
                return CommonCode.ERROR_HTTP_REQUEST;
            }
            catch (Exception ex)
            {
                Logger.Error(CommonMessage.ERROR + ex.Message, ex);
                return CommonCode.ERROR;
            }
            //Logger.Debug("result: " + result);
            //Logger.Debug("RegistryCtrl() end");
            return result;
        }


        /// <summary>
        /// レジストリ・キーを新規登録する
        /// </summary>
        /// <returns>登録の成否</returns>
        public bool CreateValue(string keyName, string isMode, string path, string uri)
        {
            //Logger.Debug("CreateValue() start");
            bool result = false;
            int level = 1;
            try
            {
                // レジストリ・キーを新規作成
                RegistryKey rKey = Registry.LocalMachine.CreateSubKey(keyName);

                // レジストリの値を設定
                rKey.SetValue(isMode, level);
                rKey.SetValue(path, uri);

                // 開いたレジストリを閉じる
                rKey.Close();
                result = true;

            }
            catch (Exception ex)
            {
                Logger.Error(ex.Message, ex);
                result = false;
            }
            Logger.Info("CreateValue() result: " + result);
            //Logger.Debug("CreateValue() end.");
            return result;
        }

        /// <summary>
        /// 登録されているサイトリストの設定内容がすべて合致するか確認する
        /// </summary>
        /// <param name="path">保存されているxmlファイルのパス</param>
        /// <param name="SLIPath">サーバー上のxmlファイルのパス</param>
        /// <returns>比較結果(true:すべて合致, false:1つ以上異なる)</returns>
        public bool CompareSiteList(string path, string SLIPath, string commentValue)
        {
            //Logger.Debug("CompareSiteList() start");

            string tagSitelist = "site-list";
            string tagSite = "site";
            string tagUrl = "url";
            string tagMode = "open-in";
            string tagComment = "comment";
            int correctNum = 0; //ソニー生命から始まるURLで一致する数
            int wrongNum = 0; //ソニー生命から始まるURLで設定が異なる数
            int num = 0; //ソニー生命から始まるURLの数
            bool result = false;
            try
            {
                if (!File.Exists(path))
                {
                    //ファイルが存在しない場合
                    Logger.Debug(CommonMessage.MSG_NO_FILE);
                    result = false;
                }
                else
                {
                    XDocument xmlLocal = XDocument.Load(path);
                    XDocument xmlServ = XDocument.Load(SLIPath);
                    //ローカルに保存済みのXMLファイル内の要素を取得する
                    XElement locSitelist = xmlLocal.Element(tagSitelist);
                    IEnumerable<XElement> locSiteRows = locSitelist.Elements(tagSite);
                    //サーバー上のXMLファイル内の要素を取得する
                    XElement servSitelist = xmlServ.Element(tagSitelist);
                    IEnumerable<XElement> servSiteRows = servSitelist.Elements(tagSite);

                    foreach(var servSite in servSiteRows)
                    {
                        if(servSite.Attribute(tagComment).Value.StartsWith(commentValue) == false)
                        {
                            continue;
                        }
                        var servUrl = servSite.Attribute(tagUrl).Value;
                        var servMode = servSite.Element(tagMode).Value;
                        num++;

                        foreach (XElement locSite in locSiteRows)
                        {
                            if (locSite.Attribute(tagComment).Value.StartsWith(commentValue) == false)
                            {
                                continue;
                            }
                            if (servUrl == locSite.Attribute(tagUrl).Value)
                            {
                                if (servMode != locSite.Element(tagMode).Value)
                                {
                                    Logger.Debug("wrong url: " + servUrl);
                                    wrongNum++;
                                }
                                else
                                {
                                    correctNum++;
                                }
                            }
                        }
                    }

                    if (wrongNum != 0)
                    {
                        //設定が誤っているものがある
                        Logger.Debug("wrong setting = " + wrongNum);
                        result = false;
                    }
                    else if (correctNum != num)
                    {
                        //ソニー生命から始まるURLが設定に不足している
                        Logger.Debug("not enough settings");
                        result = false;
                    }
                    else
                    {
                        result = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex.Message, ex);
                result = false;
            }
            Logger.Info("CompareSiteList() result = " + result);
            //Logger.Debug("CompareSiteList() end.");
            return result;
        }

        /// <summary>
        /// ファイルが書き込み可能か、調べる
        /// ※ファイルが無い時は「書き込み不可」を返す。
        /// </summary>
        /// <param name="filePath">ファイル名</param>
        /// <returns>true: 書き込み可能 false: 書き込み不可か、ファイルが無い</returns>
        public bool IsWritableFile(string filePath)
        {
            try
            {
                // 書き込みモードでファイルを開けるか確認
                using (FileStream fp = File.Open(filePath, FileMode.Open, FileAccess.Write))
                {
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }
    }

    public static class CommonMessage
    {
        public static readonly string ERROR = "エラーが発生しました。";
        public static readonly string ERROR_EXE = "起動に失敗しました。";
        public static readonly string ERROR_DOUBLE_EXECUTION = "プログラムが二重起動されています。";
        //public static readonly string ERROR_WRONG_FILE = "登録されているサイトリストの設定が既定の設定とは異なります。";
        public static readonly string ERROR_READ_FILE = "ファイルの読み込みに失敗しました。";
        public static readonly string ERROR_REGISTRY_FAILURE = "レジストリの登録に失敗しました。";
        public static readonly string ERROR_ACCESS_URL = "アクセスに失敗しました。";
        public static readonly string MSG_NO_IEMODE = "IEモードが無効です。";
        public static readonly string MSG_UPDATE_MESSAGE = "更新が完了しました。";
        public static readonly string MSG_OTHER_FILE = "指定ファイル以外が登録されています。";
        public static readonly string MSG_NO_KEY = "レジストリが未登録です。";
        public static readonly string MSG_REGIST = "レジストリの新規登録が完了しました。";
        public static readonly string MSG_DOWNLOAD_FAILURE = "ファイルのダウンロードに失敗しました。";
        public static readonly string MSG_NEWEST_FILE = "ファイルは最新です。";
        public static readonly string MSG_NO_FILE = "ファイルが存在しません。";
        public static readonly string MSG_NO_AUTHORITY = "ファイルの書き込み権限がありません。";
        public static readonly string MSG_DOWNLOAD_SUCCESS = "ファイルの書き込みが正常に終了しました。";
        public static readonly string MSG_ALREADY_EXE = "本日はすでに更新確認済みです。";
        public static readonly string MSG_FAILURE = "異常終了しました。";

        public static readonly string DIALOG_TITLE = "代理店ネットワークシステム";
    }

    public static class CommonCode
    {
        //デバッグ用
        public static readonly int OK = 0; //処理成功
        public static readonly int ERROR_ARG = 900; //起動時引数エラー
        public static readonly int ERROR_TIMEOUT = 901; //タイムアウト
        public static readonly int ERROR_DOUBLE_EXECUTION = 902; //二重起動エラー
        public static readonly int ERROR_HTTP_REQUEST = 903; //Http通信エラー
        public static readonly int ERROR_READ_FILE = 904; //ファイル読み込みエラー
        public static readonly int ERROR = 999; //エラー
        //メッセージダイアログにも表示するエラー
        public static readonly int CODE_FALSE_IEMODE = 1; //IEモードが無効 メッセージNo.1表示
        public static readonly int CODE_OTHER_FILE = 2; //登録されているサイトリストパスが指定のもの以外である メッセージNo.2表示
        public static readonly int CODE_NO_AUTHORITY = 3; //サイトリストパスのユーザー権限が操作不可　メッセージNo.3表示
        public static readonly int CODE_NO_KEY = 4; //HKLMにもHKCUにもキーが未登録　メッセージNo.4
        public static readonly int CODE_FALSE_IEMODE_HKCU = 5; //メッセージNo.5
        public static readonly int CODE_LOGIN_VPN = 6;
        public static readonly int CODE_ALREADY_EXE = 50; //当日すでに起動済
        public static readonly int CODE_EXE = 51; //未起動
    }

    public class CommonUtil
    {
        private static readonly HttpClient _httpClient = new HttpClient();

        public static async Task<HttpResponseMessage> DownloadFileAsync(string uri, string path)
        {
            //HttpClient でファイルを非同期でダウンロードする 
            HttpResponseMessage res = await _httpClient.GetAsync(uri, HttpCompletionOption.ResponseHeadersRead);

            using (var fileStream = File.Create(path))
            {
                using (var httpStream = await res.Content.ReadAsStreamAsync())
                {
                    try
                    {
                        httpStream.CopyTo(fileStream);
                    }
                    catch (Exception ex)
                    {
                        Logger.Error(ex.Message, ex);
                    }

                }
            }

            return res;

        }

    }

    public static class CommonPath
    {
        public static readonly string executionPath = AppDomain.CurrentDomain.BaseDirectory;
        public static readonly string iniPath = executionPath + "SiteListCtrl.ini";
        public static readonly string historyFilePath = executionPath + "ExecutionHistory.txt";
    }
}
