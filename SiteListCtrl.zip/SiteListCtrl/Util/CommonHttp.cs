﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace SiteListCtrl.Util
{
    public class CommonHttp
    {
        private static readonly HttpClient _httpClient;

        static CommonHttp()
        {
            _httpClient = new HttpClient();
        }

        public async Task<HttpStatusCode> GetStatusCodeAsync(string uri)
        {
            //Logger.Debug("GetStatusCodeAsync() start");
            var request = new HttpRequestMessage
            {
                Method = HttpMethod.Get,
                RequestUri = new Uri(uri)
            };

            var response = await _httpClient.SendAsync(request);
            Logger.Debug("HttpStatusCode: " + response.StatusCode);
            //Logger.Debug("GetStatusCodeAsync() end");
            return response.StatusCode;
        }

        /// <summary>
        /// サーバ上のファイルをローカルファイルにコピーする
        /// </summary>
        /// <param name="downloadUri">サーバー上のファイルURI</param>
        /// <param name="localPath">保存先パス</param>
        public async Task<bool> CopyFileAsync(string downloadUri, string localPath)
        {
            //Logger.Debug("CopyFileAsync() start");
            HttpClient client = new HttpClient();
            bool result = false;
            try
            {
                HttpResponseMessage res = await client.GetAsync(downloadUri, HttpCompletionOption.ResponseContentRead);

                using (var fileStream = File.Create(localPath))
                {
                    using (var httpStream = await res.Content.ReadAsStreamAsync())
                    {
                        httpStream.CopyTo(fileStream);
                        fileStream.Flush();
                    }
                }
                result = true;

            }
            catch (HttpRequestException hre)
            {
                Logger.Error(hre.Message, hre);
                result = false;

            }
            catch (Exception e)
            {
                Logger.Error(e.Message, e);
                result = false;
            }
            Logger.Debug("CopyFileAsync() result = " + result);
            //Logger.Debug("CopyFileAsync() end.");
            return result;
        }
    }
}
