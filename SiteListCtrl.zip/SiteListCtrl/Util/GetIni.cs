﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SiteListCtrl.Util.GetIni
{
    class GetIni
    {
        public static Dictionary<string, string> GetReadValue()
        {
            //Logger.Debug("GetReadValue() start");
            var iniDictionary = new Dictionary<string, string>();
            try
            {
                //iniファイルの値を取得
                var s = Ini.Read<Settings>("Settings", CommonPath.iniPath);
                var m = Ini.Read<Message>("Message", CommonPath.iniPath);
                iniDictionary.Add("keyNameLM", s.keyNameLM);
                iniDictionary.Add("keyNameCU", s.keyNameCU);
                iniDictionary.Add("isMode", s.isMode);
                iniDictionary.Add("sitelistPath", s.sitelistPath);
                iniDictionary.Add("downloadUri", s.downloadUri);
                iniDictionary.Add("comment", s.comment);
                iniDictionary.Add("msg1", m.msg1);
                iniDictionary.Add("msg2", m.msg2);
                iniDictionary.Add("msg3", m.msg3);
                iniDictionary.Add("msg4", m.msg4);
                iniDictionary.Add("msg5", m.msg5);
                iniDictionary.Add("msg6", m.msg6);
            }
            catch(Exception ex)
            {
                Logger.Error(ex.Message, ex);
                iniDictionary = null;
            }
            //Logger.Debug("GetReadValue() end.");
            return iniDictionary;
        }
    }


    public class Settings
    {
        public string keyNameLM;
        public string keyNameCU;
        public string isMode;
        public string sitelistPath;
        public string downloadUri;
        public string comment;
    }

    public class Message
    {
        public string msg1;
        public string msg2;
        public string msg3;
        public string msg4;
        public string msg5;
        public string msg6;
    }

    public static class Ini
    {
        [DllImport("KERNEL32.DLL")]
        public static extern uint GetPrivateProfileString(string lpAppName, string lpKeyName, string lpDefault, StringBuilder lpReturnedString, uint nSize, string lpFileName);

        [DllImport("KERNEL32.DLL")]
        public static extern uint GetPrivateProfileInt(string lpAppName, string lpKeyName, int nDefault, string lpFileName);

        /// <summary>
        /// iniファイルの値を取得する
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="section"></param>
        /// <param name="filepath"></param>
        /// <returns></returns>
        public static T Read<T>(string section, string filepath)
        {
            T ret = (T)Activator.CreateInstance(typeof(T));

            foreach (var n in typeof(T).GetFields())
            {
                if (n.FieldType == typeof(int))
                {
                    n.SetValue(ret, (int)GetPrivateProfileInt(section, n.Name, 0, Path.GetFullPath(filepath)));
                }
                else if (n.FieldType == typeof(uint))
                {
                    n.SetValue(ret, GetPrivateProfileInt(section, n.Name, 0, Path.GetFullPath(filepath)));
                }
                else
                {
                    var sb = new StringBuilder(1024);
                    GetPrivateProfileString(section, n.Name, "", sb, (uint)sb.Capacity, Path.GetFullPath(filepath));
                    n.SetValue(ret, sb.ToString());
                }
            };

            return ret;
        }

    }



}
