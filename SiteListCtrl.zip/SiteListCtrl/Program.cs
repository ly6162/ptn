﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Threading;
using Microsoft.Win32;
using System.IO;
using System.Xml.Linq;
using SiteListCtrl.Util;
using System.Net.Http;
using System.Threading.Tasks;
using System.Net;
using SiteListCtrl.Util.GetIni;

namespace SiteListCtrl
{
    class Program
    {
        private enum Code : int
        {
            SUCCESS = 0,
            FALSE_IEMODE,
            OTHER_PATH,
            NO_AUTHORITY,
            NO_KEY,
            FALSE_IEMODE_HKCU,
            LOGIN_VPN,
            ALREADY_EXE = 50
        }

        /// <summary>
        /// アプリケーションのメイン エントリ ポイントです。
        /// </summary>
        static void Main(string[] args)
        {
            Console.WriteLine("test");
            Logger.Info("### START");
            Run run = new Run();
            int resultCode = CommonCode.ERROR;
            bool isRegist = false;
            bool isError = false; //メッセージダイアログの種類がエラーかどうか

            // 二重起動防止
            Mutex mutex = new Mutex(false, Application.ProductName);
            try
            {
                if (mutex.WaitOne(0, false))
                {
                    try
                    {
                        //起動パラメータの取得
                        if (args.Length != 0)
                        {
                            //iniファイルを取得
                            Dictionary<string, string> iniDictionary = GetIni.GetReadValue();
                            if (iniDictionary != null)
                            {

                                for (int i = 0; i < args.Length; i++)
                                {
                                    switch (args[i])
                                    {
                                        case "regist":
                                            Task<int> regist = run.RegistryRun();
                                            isRegist = true;
                                            resultCode = regist.Result;
                                            break;
                                        case "iemodecheck":
                                            int iemodecheck = run.CheckSettingRun();
                                            resultCode = iemodecheck;
                                            break;
                                        default:
                                            Logger.Debug("起動パラメータが異なります。");
                                            resultCode = CommonCode.ERROR_DOUBLE_EXECUTION;
                                            break;
                                    }
                                }
                            }
                            else
                            {
                                Logger.Error(CommonMessage.ERROR_READ_FILE);
                                resultCode = CommonCode.ERROR_READ_FILE;
                            }
                            string msg = "";
                            switch (resultCode)
                            {
                                case (int)Code.SUCCESS:
                                    //正常終了
                                    if (isRegist)
                                    { //registモードの場合のみメッセージ表示
                                        msg = iniDictionary["msg6"];
                                    }
                                    break;
                                case (int)Code.FALSE_IEMODE:
                                    msg = iniDictionary["msg1"];
                                    break;
                                case (int)Code.OTHER_PATH:
                                    msg = iniDictionary["msg2"];
                                    break;
                                case (int)Code.NO_AUTHORITY:
                                    msg = iniDictionary["msg3"];
                                    break;
                                case (int)Code.NO_KEY:
                                    msg = iniDictionary["msg4"];
                                    break;
                                case (int)Code.FALSE_IEMODE_HKCU:
                                    msg = iniDictionary["msg5"];
                                    break;
                                case (int)Code.LOGIN_VPN:
                                    msg = iniDictionary["msg6"];
                                    break;
                                case (int) Code.ALREADY_EXE:
                                    msg = CommonMessage.MSG_ALREADY_EXE;
                                    break;
                                default:
                                    msg = CommonMessage.MSG_FAILURE;
                                    isError = true;
                                    break;
                            }
                            if(resultCode > 0 || msg != "")
                            {
                                Logger.Info("[show message] msg" + resultCode);

                                if (isError)
                                {
                                    Console.WriteLine(msg);
                                    //MessageBox.Show(msg, CommonMessage.DIALOG_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                                else
                                {
                                    Console.WriteLine(msg);
                                    //MessageBox.Show(msg, CommonMessage.DIALOG_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                }                            
                            }
                        }
                        Environment.ExitCode = resultCode;
                    }
                    catch (Exception ex)
                    {
                        Logger.Error(ex.Message, ex);
                        Environment.ExitCode = CommonCode.ERROR;
                    }
                }
                else
                {
                    Logger.Debug(CommonMessage.ERROR_DOUBLE_EXECUTION);
                    MessageBox.Show(CommonMessage.ERROR_DOUBLE_EXECUTION, CommonMessage.DIALOG_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Environment.ExitCode = CommonCode.ERROR_DOUBLE_EXECUTION;
                }
            } catch (Exception ex)
            {
                Logger.Error(ex.Message, ex);
                Environment.ExitCode = CommonCode.ERROR_DOUBLE_EXECUTION;
            }
            finally
            {
                GC.KeepAlive(mutex);
                mutex.Close();
                Logger.Info("### END  ResultCode=" + Environment.ExitCode);
            }
            
        }
    }

    public class Run {

        CommonHttp ch = new CommonHttp();
        Common cm = new Common();
        private static readonly int iecheckmode = 1;

        /// <summary>
        /// 登録処理
        /// </summary>
        /// <returns>処理結果 0: OK
        /// 51:IEモードが無効
        /// 101:IEモードが無効
        /// 103:サイトリストパスのユーザー権限が操作不可
        /// 104:HKCUに未登録
        /// 902;二重起動エラー
        /// 903;Http通信エラー
        /// 999:その他エラー発生
        /// </returns>
        public async Task<int> RegistryRun()
        {
            //Logger.Debug("RegistryRun() start");
            int registryResult = CommonCode.ERROR;
            try
            {
                //iniファイルを取得
                if (!File.Exists(CommonPath.iniPath))
                {
                    //ファイルが存在しない場合
                    Logger.Debug(CommonMessage.MSG_NO_FILE);
                    return registryResult;
                }
                Dictionary<string, string> iniDictionary = GetIni.GetReadValue();
                if (iniDictionary == null)
                {
                    Logger.Debug(CommonMessage.ERROR_READ_FILE);
                    return registryResult;
                }

                string url = iniDictionary["downloadUri"];
                //URLアクセス
                HttpStatusCode statusCode = await ch.GetStatusCodeAsync(url);
                if (statusCode != HttpStatusCode.OK)
                {
                    Logger.Error("statusCode: " + statusCode);
                    Logger.Error(CommonMessage.ERROR_ACCESS_URL);
                    return CommonCode.ERROR_HTTP_REQUEST;
                }
                //レジストリ処理
                var registryCtrl = cm.RegistryCtrl();
                Logger.Info("RegistryCtrl() result: " + registryCtrl.Result);
                registryResult = registryCtrl.Result;
            }catch(Exception ex)
            {
                Logger.Error(ex.Message, ex);
                registryResult = CommonCode.ERROR;
            }

            //処理完了
            Logger.Info("RegistryRun() result: " + registryResult);
            //Logger.Debug("RegistryRun() end.");
            return registryResult;
        }

        /// <summary>
        /// 起動チェックを行う
        /// </summary>
        /// <returns>起動チェック結果 true: 未起動 false:当日既に起動済み</returns>
        public int CheckSettingRun()
        {
            //Logger.Debug("CheckSettingRun() start");

            DateTime today = DateTime.Now;
            int checkResultCode = CommonCode.ERROR;
            UseFile rf = new UseFile();
            try
            {
                //出力ファイルを取得
                if (!File.Exists(CommonPath.historyFilePath))
                {
                    //ファイルが存在しない場合ファイルを新規作成
                    Logger.Debug(CommonMessage.MSG_NO_FILE);
                    using (FileStream fs = File.Create(CommonPath.historyFilePath)){;}
                }
                string lastRow = rf.GetLastRow(CommonPath.historyFilePath);
                if (lastRow == null)
                {
                    return checkResultCode;
                }
                DateTime dateTime;
                if (lastRow == "" || !DateTime.TryParse(lastRow, out dateTime))
                { //1行も存在しない、または日付に変換できない文字列の場合
                  //実行日時をファイルに書き込む
                    UseFile.WriteFile(CommonPath.historyFilePath);
                    var runResult = cm.RegistryCtrl(iecheckmode);
                    Logger.Info("RegistryCtrl() result: " + runResult.Result);
                    checkResultCode = runResult.Result;
                }
                else
                { //日付を比較
                    DateTime lastExeDay = DateTime.Parse(lastRow);
                    if (lastExeDay.Date < today.Date)
                    {
                        //前回起動した日時が実行日時より前の場合、実行日時をファイルに書き込む
                        UseFile.WriteFile(CommonPath.historyFilePath);
                        var runResult = cm.RegistryCtrl(iecheckmode);
                        Logger.Info("RegistryCtrl() result: " + runResult.Result);
                        checkResultCode = runResult.Result;
                    }
                    else
                    {
                        checkResultCode = CommonCode.OK; //起動済み
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex.Message, ex);
                checkResultCode = CommonCode.ERROR;
            }

            //処理完了
            Logger.Info("CheckSettingRun() result: " + checkResultCode);
            //Logger.Debug("CheckSettingRun() end.");
            return checkResultCode;
        }
    }
}
